from django.db import models

# class Sale(models.Model):
#     invoice_id       =  models.AutoField(primary_key=True)
#     discount         =  models.IntegerField()
#     total      =  models.DecimalField(max_digits=10, decimal_places=2)
#     sub_total   =  models.CharField(max_length=10)
#     products =   models.JSONField()
#     selesDate = models.DateTimeField(auto_now=True)